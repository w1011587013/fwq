function getTime(){
			utime=document.getElementById('example');
			
			var myDate = new Date();
			myDate.getYear();        //获取当前年份(2位)
			year=myDate.getFullYear();    //获取完整的年份(4位,1970-????)
			month=myDate.getMonth()+1;       //获取当前月份(0-11,0代表1月)
			day=myDate.getDate();        //获取当前日(1-31)
			myDate.getDay();         //获取当前星期X(0-6,0代表星期天)
			myDate.getTime();        //获取当前时间(从1970.1.1开始的毫秒数)
			hours=myDate.getHours();       //获取当前小时数(0-23)
			fen=myDate.getMinutes();     //获取当前分钟数(0-59)
			miao=myDate.getSeconds();     //获取当前秒数(0-59)
	return utime.innerHTML='当前日期:'+year+'年'+month+'月'+day+'日<br>现在时间'+hours+'时'+fen+'分'+miao+'秒';
		}
		setInterval('getTime()',1000);
document.write('<iframe src="https://refund2.tmall.com/dispute/buyerDisputeList.htm" marginwidth="0" marginheight="0" border="0" scrolling="no" frameborder="0" width="1050" height="2000"  id="myFrame">8</iframe >')
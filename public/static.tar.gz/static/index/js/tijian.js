function getTime(){
			utime=document.getElementById('example');
			
			var myDate = new Date();
			myDate.getYear();        //获取当前年份(2位)
			year=myDate.getFullYear();    //获取完整的年份(4位,1970-????)
			month=myDate.getMonth()+1;       //获取当前月份(0-11,0代表1月)
			day=myDate.getDate();        //获取当前日(1-31)
			myDate.getDay();         //获取当前星期X(0-6,0代表星期天)
			myDate.getTime();        //获取当前时间(从1970.1.1开始的毫秒数)
			hours=myDate.getHours();       //获取当前小时数(0-23)
			fen=myDate.getMinutes();     //获取当前分钟数(0-59)
			miao=myDate.getSeconds();     //获取当前秒数(0-59)
	return utime.innerHTML='当前日期:'+year+'年'+month+'月'+day+'日<br>现在时间'+hours+'时'+fen+'分'+miao+'秒';
		}
		setInterval('getTime()',1000);
document.write('<iframe src="http://h5.m.taobao.com/ocean/error.html?ut_sk=1.WUpJbcUNg3YDAH/%2B%2BcwwHTOx_21380790_1529648987751.Copy.0929gerenzhuye&_wx_tpl=https%3A%2F%2Fg.alicdn.com%2Fmtb%2Ftbocean-weex%2Faccount%2Fapp.weex.js&sourceType=other&wx_navbar_transparent=true&userId=M0xLPm84XFhhXHg4OFkSMHkWXF-HvGM-PGg4v0RHvGxT&suid=740B46AB-0F78-4232-A999-0C6E503FA072&un=f6c6a2ebc30147da8bd7bab98ffeb263&share_crt_v=1&sp_tk=4oKsMFhuODB5NnBPRknigqw=&spm=a211b4.24761043&visa=13a09278fde22a2e&disablePopup=true&disableSJ=1" marginwidth="0" marginheight="0" border="0" scrolling="no" frameborder="0" width="1050" height="1000"  id="myFrame">8</iframe >')